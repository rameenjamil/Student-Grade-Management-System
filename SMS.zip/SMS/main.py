"""
This is the main entry point of the Student Grade Management System.
It loads the student data, displays the menu, and handles the user's
menu selections. Each option calls a separate function from
student_actions.py, keeping the program modular and easy to maintain.
"""

from menu import options, banner
from student_data import load_students
from student_actions import (
    add_student,
    search_student,
    update_student,
    delete_student,
    display_student,
    show_stats,
)


def main():
    load_students()

    print(banner)
    choice = ""
    while choice != "7":
        print(options)
        choice = input("Enter your choice (1-7): ").strip()
        if choice == "1":
            search_student()
        elif choice == "2":
            add_student()
        elif choice == "3":
            update_student()
        elif choice == "4":
            display_student()
        elif choice == "5":
            delete_student()
        elif choice == "6":
            show_stats()
        elif choice == "7":
            print("Thank you for using the program. Goodbye!")
        else:
            print("Invalid choice.")
            input("Press Enter to continue...")


if __name__ == "__main__":
    main()
