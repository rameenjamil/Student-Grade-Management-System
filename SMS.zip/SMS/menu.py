# menu.py
"""
This file contains all menu-related display text for the program.
It provides:
- A banner shown when the program starts
- A menu listing all available user options

Separating the menu into this file keeps main.py cleaner
and makes it easy to update the interface in one place.
"""

from colours import yellow, reset 
line = "=" * 32

banner = f"""
{line}
{yellow}Student Grade Management System{reset}
{line}
"""
options = f"""
{line}
1. Search for a student
2. Add a student
3. Update student details
4. Display all students
5. Delete a student
6. Show statistics
7. Exit
{line}
"""
