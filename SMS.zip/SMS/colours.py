"""
This file stores all colour codes used in the program.
By keeping them here, the code becomes cleaner and easier to maintain.
Any part of the program that needs coloured text can import these values.
"""

red = "\033[91m"
yellow = "\033[93m"
green = "\033[92m"
magenta = "\033[95m"
reset = "\033[0m"
