"""
This file contains all the main actions used by the Student Grade
Management System. Each function here performs a specific task such as:

- Adding a new student
- Searching for students
- Updating existing records
- Displaying students by subject
- Deleting records
- Showing statistics
By keeping these actions in one file, the program remains organised
and easier to maintain."""

from colours import red, yellow, green, magenta, reset
from student_data import students, save_students



def pause_or_exit():
    """
    Displays a prompt allowing the user to return to the menu or exit.
    If the user chooses to exit, all data is saved before closing the program.
    """
    prompt = f"""
    {yellow}{"-"*30}{reset}
    Press {yellow}Enter{reset} to return to menu
    or press {yellow}7{reset} to exit the program.
    {yellow}{"-"*30}{reset}
    """
    while True:
        choice = input(prompt).strip()
        if choice == "":
            return
        elif choice == "7":
            save_students()
            print(f"{green}All data saved. Exiting the program...{reset}")
            exit()
        else:
            print(f"{red}Invalid input. Please press Enter or 7.{reset}")



def add_student():
    """
    Handles adding a new student to the system.
    Ensures that all fields are entered correctly and validates the grade
    before saving the record to the main student list.
    """

    first = ""
    while first == "":
        first = input("Enter first name: ").strip()
        if first == "":
            print(f"{red}First name cannot be empty.{reset}")

    last = ""
    while last == "":
        last = input("Enter surname: ").strip()
        if last == "":
            print(f"{red}Surname cannot be empty.{reset}")

    subject = ""
    while subject == "":
        subject = input("Enter subject: ").strip()
        if subject == "":
            print(f"{red}Subject cannot be empty.{reset}")

    grade_valid = False
    while not grade_valid:
        grade_input = input("Enter grade (0-100): ").strip()
        if grade_input.isdigit():
            value = int(grade_input)
            if 0 <= value <= 100:
                grade_valid = True
            else:
                print(f"{red}Grade must be between 0 and 100.{reset}")
        else:
            print(f"{red}Grade must be a number.{reset}")

    
    students.append(
        {
            "first_name": first,
            "surname": last,
            "subject": subject,
            "grade": value,
        }
    )

    save_students()

    print(f"{green}Student {first} {last} added successfully!{reset}\n")
    pause_or_exit()


def search_student():
    """
    Allows the user to search for students by first name or surname.
    Displays all matching records and handles cases where no match is found.
    """

    term = input("Enter first name or surname: ").strip().lower()

    if term == "":
        print(f"{red}Search term cannot be empty.{reset}")
        pause_or_exit()
        return

    found = False
    for s in students:
        if term in s["first_name"].lower() or term in s["surname"].lower():
            found = True
            print(
                f"""
            {'-'*30}
            {yellow}Name:{reset} {s['first_name']} {s['surname']}
            {yellow}Subject:{reset} {s['subject']}
            {yellow}Grade:{reset} {s['grade']}
            {'-'*30}
            """
            )

    if not found:
        print(f"{red}No matching student found.{reset}")

    pause_or_exit()


def display_student():
    """
    Shows all student records grouped by subject.
    Helps organise the data visually and makes it easier to find students
    based on the subject they study.
    """

    if not students:
        print(f"{red}No students found.{reset}")
        pause_or_exit()
        return

    # Collect unique subjects
    subjects = []
    for s in students:
        if s["subject"] not in subjects:
            subjects.append(s["subject"])

    for subject in subjects:
        print(f"\n{yellow}===== {subject.capitalize()} ====={reset}")
        for s in students:
            if s["subject"] == subject:
                name = s["first_name"].capitalize() + " " + s["surname"].capitalize()
                print(f"{name} — {s['grade']}")

    print()
    pause_or_exit()


def update_student():
    """
    Allows the user to update a student's information.
    Supports updating the first name, surname, grade,
    or all details for a specific subject entry.
    """

    first = input("Enter FIRST NAME: ").strip().lower()
    last = input("Enter SURNAME: ").strip().lower()

    if first == "" or last == "":
        print(f"{red}Names cannot be empty.{reset}")
        pause_or_exit()
        return

    # Find all matching entries
    matches = []
    for i, s in enumerate(students):
        if s["first_name"].lower() == first and s["surname"].lower() == last:
            matches.append((i, s))

    if not matches:
        print(f"{red}No student found named {first.title()} {last.title()}.{reset}")
        pause_or_exit()
        return

    # Show subject records
    print(f"\nStudent found: {magenta}{first.title()} {last.title()}{reset}")
    for index, (_, entry) in enumerate(matches, 1):
        print(f"{index}. {entry['subject']} — {entry['grade']}")

    choice = input("\nSelect a record number: ").strip()
    if not choice.isdigit() or not (1 <= int(choice) <= len(matches)):
        print(f"{red}Invalid selection.{reset}")
        pause_or_exit()
        return

    real_index, entry = matches[int(choice) - 1]

    print(
        """\nWhat do you want to update?")
    1. First Name")
    2. Surname")
    3. Grade")
    4. All of the above
    """
    )

    option = input("Your choice: ").strip()

    # Update first name
    if option in ("1", "4"):
        new_first = ""
        while new_first == "":
            new_first = input("New first name: ").strip()
        entry["first_name"] = new_first

    # Update surname
    if option in ("2", "4"):
        new_last = ""
        while new_last == "":
            new_last = input("New surname: ").strip()
        entry["surname"] = new_last

    # Update grade
    if option in ("3", "4"):
        valid = False
        while not valid:
            new_grade = input("New grade (0-100): ").strip()
            if new_grade.isdigit() and 0 <= int(new_grade) <= 100:
                entry["grade"] = int(new_grade)
                valid = True
            else:
                print(f"{red}Invalid grade.{reset}")

    students[real_index] = entry
    save_students()

    print(f"{green}Record updated successfully!{reset}\n")
    pause_or_exit()


def delete_student():
    """
    Delete one subject record or all records belonging to a student.
    The function allows users to:
    - Search for a student by first name + surname
    - Choose which subject record to delete OR delete all of them
    """

    # 1. Get student name to search for
    first_name_input = input("Enter FIRST NAME: ").strip().lower()
    surname_input = input("Enter SURNAME: ").strip().lower()

    if first_name_input == "" or surname_input == "":
        print(f"{red}Names cannot be empty.{reset}")
        pause_or_exit()
        return

    # 2. Find all matching records (student may have multiple subjects)
    # stores (list_index, record_dictionary)
    matching_records = []

    for list_index, record in enumerate(students):
        if (
            record["first_name"].lower() == first_name_input
            and record["surname"].lower() == surname_input
        ):
            matching_records.append((list_index, record))

    # If no records found for that name
    if not matching_records:
        print(f"{red}No student found with that name.{reset}")
        pause_or_exit()
        return

    # 3. Display all subject records found for the student
    print(
        f"\nStudent found: {yellow}{first_name_input.title()} {surname_input.title()}{reset}"
    )

    for display_number, (list_index, record) in enumerate(matching_records, 1):
        print(f"{display_number}. {record['subject']} — {record['grade']}")

    print(f"{yellow}A. Delete ALL records{reset}")

    # 4. Ask user what they want to delete
    user_choice = input("\nYour choice: ").strip().lower()

    # OPTION A — Delete all records

    if user_choice == "a":
        # Remove from the end to avoid index shifting problems
        for list_index, _ in reversed(matching_records):
            students.pop(list_index)

        save_students()
        print(f"{green}All records deleted.{reset}")
        pause_or_exit()
        return

    # OPTION : delete a specific one

    if not user_choice.isdigit():
        print(f"{red}Invalid choice.{reset}")
        pause_or_exit()
        return

    record_number = int(user_choice)

    # Validate number
    if not (1 <= record_number <= len(matching_records)):
        print(f"{red}Choice out of range.{reset}")
        pause_or_exit()
        return

    # Convert the selection number to actual index
    index_to_delete, selected_record = matching_records[record_number - 1]

    # Delete the chosen record
    students.pop(index_to_delete)
    save_students()

    print(f"{green}Record deleted successfully.{reset}")
    pause_or_exit()



def show_stats():
    """
    Shows statistics for a selected subject.
    Displays: total records, average grade, highest and lowest grade,
    and the names of students who achieved them.
    """

    # If no students exist, we cannot calculate anything
    if not students:
        print(f"{red}No data available.{reset}")
        pause_or_exit()
        return

    # 1: Build a list of all unique subjects

    subjects = []
    for student in students:
        if student["subject"] not in subjects:
            subjects.append(student["subject"])

    # 2: Show subjects as a numbered list

    print("\nAvailable subjects:")
    for number, subject in enumerate(subjects, 1):
        print(f"{number}. {subject}")

    # Ask user to choose a subject by number
    choice = input("\nSelect subject number: ").strip()

    if not choice.isdigit() or not (1 <= int(choice) <= len(subjects)):
        print(f"{red}Invalid choice.{reset}")
        pause_or_exit()
        return

    selected_subject = subjects[int(choice) - 1]

    # 3: Collect all records for the chosen subject

    subject_records = []
    for student in students:
        if student["subject"] == selected_subject:
            subject_records.append(student)

    # Extract all grades for this subject
    grades = []
    for student in subject_records:
        grades.append(student["grade"])

    # 4: Calculate statistics

    total_records = len(grades)
    average_grade = sum(grades) / total_records
    highest_grade = max(grades)
    lowest_grade = min(grades)

    # 5: Find names with highest grade

    highest_grade_names = []
    for student in subject_records:
        if student["grade"] == highest_grade:
            full_name = student["first_name"].title() + " " + student["surname"].title()
            highest_grade_names.append(full_name)

    # 6: Find names with lowest grade
    lowest_grade_names = []
    for student in subject_records:
        if student["grade"] == lowest_grade:
            full_name = student["first_name"].title() + " " + student["surname"].title()
            lowest_grade_names.append(full_name)

    # 7: Display results clearly

    print(
        f"""
{'-'*30}
{yellow}Statistics for {selected_subject}:{reset}

Total records: {total_records}
Average grade: {average_grade:.2f}

Highest grade: {highest_grade}
Students: {', '.join(highest_grade_names)}

Lowest grade: {lowest_grade}
Students: {', '.join(lowest_grade_names)}
{'-'*30}
"""
    )

    pause_or_exit()
