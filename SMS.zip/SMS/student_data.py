# student_data.py
"""
This file handles all data storage for the program.
It contains:
- A list that stores every student record in memory
- A function to load student data from students.txt
- A function to save updated data back into the file

By keeping all file-read and file-write operations here,
the rest of the program stays organised and easier to maintain.
"""


students = []


def load_students():
    """Load all students from students.txt into the list."""
    students.clear()  # prevents duplication when returning to menu

    try:
        with open("students.txt", "r") as file:
            for line in file:
                first, last, subject, grade = line.strip().split(",")
                students.append(
                    {
                        "first_name": first,
                        "surname": last,
                        "subject": subject,
                        "grade": int(grade),
                    }
                )
    except FileNotFoundError:
        pass  # file may not exist yet


def save_students():
    """Save all students from the list into students.txt."""
    with open("students.txt", "w") as file:
        for s in students:
            file.write(
                f"{s['first_name']},{s['surname']},{s['subject']},{s['grade']}\n"
            )
